-- BASE DE DATOS PARA EL PROYECTO
-- Ejecutar en Supabase > SQL Editor.

-- Tabla complementaria para mostrar datos de usuarios.
create table if not exists public.perfiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nombre text not null,
  tipo_usuario text not null default 'Alumno',
  creado_en timestamptz not null default now()
);

alter table public.perfiles enable row level security;

-- Cada usuario autenticado puede consultar su propio perfil.
create policy "Usuarios pueden consultar su perfil"
on public.perfiles
for select
to authenticated
using (auth.uid() = id);

-- IMPORTANTE:
-- Las contraseñas NO se guardan en esta tabla.
-- Supabase Auth administra las credenciales de forma segura.
-- Los usuarios se crean desde Authentication > Users.
