# Pequeña aplicación web con base de datos en la nube

## Tecnología utilizada
- HTML, CSS y JavaScript para la página web.
- Supabase para autenticación y base de datos PostgreSQL en la nube.
- Supabase Auth para correo + contraseña.

## Configuración
1. Crear un proyecto en Supabase.
2. En SQL Editor ejecutar `database.sql`.
3. En Authentication > Users crear 3 usuarios, por ejemplo:
   - alumno1@demo.com / Demo12345!
   - alumno2@demo.com / Demo12345!
   - profesor@demo.com / Demo12345!
4. Para obtener el ID de cada usuario, revisar Authentication > Users.
5. Insertar sus perfiles en la tabla `perfiles`, usando el mismo UUID de cada usuario.
6. Copiar la URL del proyecto y la publishable key desde la configuración de API.
7. Pegarlas en `app.js`.
8. Abrir `index.html` con un servidor local o publicarlo en un hosting estático.

## Prueba para la exposición
- Abrir la página.
- Probar un usuario válido.
- Mostrar que aparece el correo del usuario autenticado.
- Cerrar sesión.
- Probar una contraseña incorrecta y mostrar el mensaje de error.
- Entrar a Supabase > Table Editor y mostrar la tabla `perfiles`.
- Mostrar también Authentication > Users para demostrar los usuarios creados.

## Nota de seguridad
No se debe crear una tabla propia con contraseñas en texto plano. Supabase Auth administra las credenciales. La tabla `perfiles` solo contiene información complementaria.
