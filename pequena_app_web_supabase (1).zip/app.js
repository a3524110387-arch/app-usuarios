// Configuración del proyecto Supabase
const SUPABASE_URL = "https://fzcrpbfsulzewpnzbxye.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_LUAzbCjS89V5q-Fbu75xCA_zNXu7NjP";

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Elementos de la página
const loginForm = document.getElementById("loginForm");
const loginCard = document.getElementById("loginCard");
const userCard = document.getElementById("userCard");
const message = document.getElementById("message");
const submitBtn = document.getElementById("submitBtn");
const logout = document.getElementById("logout");
const steps = document.querySelectorAll("#steps li");

const campos = {
  inicial: document.getElementById("avatar"),
  nombre: document.getElementById("perfilNombre"),
  tipo: document.getElementById("perfilTipo"),
  correo: document.getElementById("perfilCorreo"),
  fecha: document.getElementById("perfilFecha"),
  id: document.getElementById("perfilId"),
  aviso: document.getElementById("perfilAviso"),
};

// Marca en el esquema cuántos pasos del proceso se han completado (0 a 3).
function marcarPasos(hasta) {
  steps.forEach((li, i) => {
    li.classList.toggle("done", i < hasta);
    li.classList.toggle("active", i === hasta);
  });
}

function formatearFecha(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("es-MX", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

// Consulta la tabla `perfiles` en la nube y muestra los datos del usuario.
async function mostrarSesion(user) {
  marcarPasos(2);
  loginCard.classList.add("hidden");
  userCard.classList.remove("hidden");

  campos.correo.textContent = user.email;
  campos.id.textContent = user.id;
  campos.nombre.textContent = "Cargando…";
  campos.tipo.textContent = "";
  campos.fecha.textContent = "—";
  campos.aviso.textContent = "";

  const { data, error } = await supabaseClient
    .from("perfiles")
    .select("nombre, tipo_usuario, creado_en")
    .eq("id", user.id)
    .maybeSingle();

  if (error) {
    campos.nombre.textContent = user.email;
    campos.inicial.textContent = user.email.charAt(0).toUpperCase();
    campos.aviso.textContent =
      "No se pudo leer la tabla perfiles. Revisa la política de seguridad (RLS) en Supabase.";
    return;
  }

  if (!data) {
    campos.nombre.textContent = user.email;
    campos.inicial.textContent = user.email.charAt(0).toUpperCase();
    campos.aviso.textContent =
      "Este usuario existe en Authentication, pero todavía no tiene fila en la tabla perfiles.";
    return;
  }

  campos.nombre.textContent = data.nombre;
  campos.inicial.textContent = data.nombre.charAt(0).toUpperCase();
  campos.tipo.textContent = data.tipo_usuario;
  campos.fecha.textContent = formatearFecha(data.creado_en);
  marcarPasos(3);
}

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  message.textContent = "";
  message.classList.remove("error");
  submitBtn.disabled = true;
  submitBtn.textContent = "Verificando…";
  marcarPasos(1);

  const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });

  submitBtn.disabled = false;
  submitBtn.textContent = "Entrar";

  if (error) {
    marcarPasos(0);
    message.classList.add("error");
    message.textContent = "Correo o contraseña incorrectos. Revisa los datos e inténtalo de nuevo.";
    return;
  }

  await mostrarSesion(data.user);
});

logout.addEventListener("click", async () => {
  await supabaseClient.auth.signOut();
  userCard.classList.add("hidden");
  loginCard.classList.remove("hidden");
  loginForm.reset();
  marcarPasos(0);
});

async function cargarSesion() {
  const { data } = await supabaseClient.auth.getSession();
  if (data.session) {
    await mostrarSesion(data.session.user);
  } else {
    marcarPasos(0);
  }
}

cargarSesion();
